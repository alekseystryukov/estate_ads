{% extends "gis/google/google-map.js" %}
{% block vars %}{# No vars here because used within GoogleMapSet #}{% endblock %}